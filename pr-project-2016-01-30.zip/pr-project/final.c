/*To analyze the 3d shapes and to demonstrate the many of the glut interactive
interface with mouse and keyboard interface*/

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#ifdef __APPLE__
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif

//#define ROT_INC		0.1

static char label[100]; 
static char label1[100]; 
int solid=0;

void  drawStringBig (char *s) 
{ 
  unsigned int i; 
  for (i = 0; i < strlen (s); i++) 
    glutBitmapCharacter (GLUT_BITMAP_HELVETICA_18, s[i]); 
}; 
 
/* forward declare the default drawing function */
void drawCube(void);

/*
 * local static variables: g_rotate used to keep track of global rotation
 * g_rotInc is the rotation increment each frame
 *
 */
static GLfloat g_rotate = 0;
static GLfloat ROT_INC = 0.1;
static GLfloat g_rotInc = 0.1; /* degree increment for rotation animation */

/* function pointer to a function called by display to draw the geometry */
static void (*drawPrimP)(void) = drawCube;

/*
 * basic geometry drawing functions - just wrappers to the glut
 * wire drawing functions
 */
void drawSphere(void)
{
	if(solid==0)
    glutWireSphere(6.0,20,20);
    else
    glutSolidSphere(6.0,20,20);
}


void drawCube(void) 
{
     if(solid==0)
	glutWireCube(6.0);
	else
	glutSolidCube(6.0);
}

void drawCone(void) 
{   if(solid==0)
	glutWireCone(6.0, 8.0, 10, 20);
	else
	glutSolidCone(6.0,8.0,10,20);
	
}

void drawTorus(void) 
{
     if(solid==0)
	glutWireTorus(1.0, 6.0, 10, 20);
	else
	glutSolidTorus(1.0, 6.0, 10, 20);
	
}

void drawIcos(void) 
{
	glPushMatrix();
	glScalef(6.0,6.0,6.0);
	if(solid==0)
	glutWireIcosahedron();
	else
	glutSolidIcosahedron();
	
	glPopMatrix();
}

void drawTeapot(void) 
{if(solid==0)
	glutWireTeapot(6.0);
	else
	glutSolidTeapot(6.0);
	
}
void drawTetra(void) 
{
    glPushMatrix();
	glScalef(6.0,6.0,6.0);
	if(solid==0)
	glutWireIcosahedron();
	else
	glutSolidIcosahedron();
	
	glPopMatrix();
}

/*
 * setPrim
 *
 * callback, called by the GLUT when the user selects a menu option.
 * This function currently contains "magic numbers" in that the menu numbers
 * and their functions are hard coded. A better option would be to use macros
 * or have a data structure that relates menu number, name and function...
 */
void setPrim(int value) 
{
         
	switch(value) 
    {
	case 1:
	drawPrimP = drawSphere;
//		drawPrimP = drawTetra;
		break;
	case 2:
		drawPrimP = drawCube;
		
		break;
	case 3:
		drawPrimP = drawCone;
		break;
	case 4:
		drawPrimP = drawTorus;
		break;
	case 5:
		drawPrimP = drawIcos;
		break;
	case 6:
		drawPrimP = drawTeapot;
		break;
	case 7:
		glClearColor(1.0, 1.0, 1.0, 1.0);
		 glColor3f(0.0, 0.0, 0.0);
		break;
    case 8:
		glClearColor(0.0, 0.0, 0.0, 0.0);
		 glColor3f(1.0, 1.0, 1.0);
		break;
	case 9:
		g_rotInc += 1.5;
		break;
	case 10:
        g_rotInc -= 1.5;
		break;
	case 11:
        glRotatef(g_rotate,1.0,0.0,0.0);
        break;	
	case 12:
        glRotatef(g_rotate,0.0,1.0,0.0);
		break;
	case 13:
        glRotatef(g_rotate,0.0,0.0,1.0);
		break;
	case 14:
        glColor3f(1.0, 0.0, 0.0);
		break;
	case 15:
        glColor3f(0.0, 1.0, 0.0);
		break;
	case 16:
        glColor3f(0.0, 0.0, 1.0);
		break;
    case 17:
        ROT_INC=0;
        g_rotInc = 0.0;
		break;    
    case 25:
       exit(0);
		break;
	
	default:
		fprintf(stderr, "3dPrim: unknown menu option %d\n", value);
		break;
	}
}

/*
 * display
 *
 * This function is called by the GLUT to display the graphics
 *
 */
void display(void)
{
    glClear( GL_COLOR_BUFFER_BIT );

	/* set matrix mode to modelview */
    glMatrixMode(GL_MODELVIEW);
    
    sprintf (label, " Prepared by: Pavan Wadawadagi, Rashmi Gangal"); 
    glRasterPos2f (-20.0F, -10.0F); 
    drawStringBig (label);
    
    
    sprintf (label1, " 3D SHAPE ANALYSIS SYSTEM");
    glRasterPos2f (-5.0F, 10.5F); 
    drawStringBig (label1);

    
	/* save matrix */
	glPushMatrix();

	/* global rotation */
	glRotatef(g_rotate,1.0,0.0,0.0);
	
	

	/* draw the geometry */
	(*drawPrimP)();

	/* restore matrix */
	glPopMatrix();

	/* swap buffers to display the frame */
 	glutSwapBuffers();
}


/*
 * myReshape
 *
 * This function is called whenever the user (or OS) reshapes the
 * OpenGL window. The GLUT sends the new window dimensions (x,y)
 *
 */
void myReshape(int w, int h)
{
	/* set viewport to new width and height */
	/* note that this command does not change the CTM */
    glViewport(0, 0, w, h);

	/* 
	 * set viewing window using perspective projection
	 */
    glMatrixMode(GL_PROJECTION); 
    glLoadIdentity(); /* init projection matrix */

	/* perspective parameters: field of view, aspect, near clip, far clip */
	gluPerspective( 60.0, (GLdouble)w/(GLdouble)h, 0.1, 40.0);

	/* set matrix mode to modelview */
    glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	gluLookAt(0.0, 0.0, 20.0, /* eye at (0,0,20) */
			  0.0, 0.0, 0.0, /* lookat point */
			  0.0, 1.0, 0.0); /* up is in +ive y */
}

/*
 * myKey
 *
 * responds to key presses from the user
 */
void myKey(unsigned char k, int x, int y)
{
	switch (k) 
    {
		case 'q':
		case 'Q':	exit(0);
		break;
		case 'w':
		case 'W':	solid=0;
		break;
		case 's':
		case 'S':	solid=1;
		break;
		case 'r':
		case 'R':	glColor3f(1.0, 0.0, 0.0);
		break;
		case 'g':
		case 'G':   glColor3f(0.0, 1.0, 0.0);
		break;
		case 'b':
		case 'B':	glColor3f(0.0, 0.0, 1.0);
		break;
	default:
		printf("Unknown keyboard command \'%c\'.\n", k);
		break;
	}
}


/*
 * myMouse
 *
 * function called by the GLUT when the user presses a mouse button
 *
 * Here we increment the global rotation rate with each press - left to do a
 * positive increment, right for negative, middle to reset
 */
void myMouse(int btn, int state, int x, int y)
{   

    //if(btn==GLUT_LEFT_BUTTON && state == GLUT_DOWN) g_rotInc += ROT_INC;
	if(btn==GLUT_MIDDLE_BUTTON && state == GLUT_DOWN) g_rotInc = ROT_INC;
	/* if(btn==GLUT_RIGHT_BUTTON && state == GLUT_DOWN) g_rotInc -= ROT_INC;
	*/
	/* force redisplay */
	glutPostRedisplay();
}   

/*
 * myIdleFunc
 *
 * increments the rotation variable within glutMainLoop
 */
void myIdleFunc(void) 
{
	g_rotate += g_rotInc;
	/* force glut to call the display function */
	glutPostRedisplay();
}



void special(int key, int x, int y)
{
  

  switch (key) {
  case GLUT_KEY_F1:
    drawPrimP = drawSphere;
    break;
  case GLUT_KEY_F2:
    drawPrimP = drawCube;
    break;
  case GLUT_KEY_F3:
    drawPrimP = drawCone;
    break;
  case GLUT_KEY_F4:
   drawPrimP = drawTorus;
    break;
  case GLUT_KEY_F5:
    drawPrimP = drawIcos;
    break;
  case GLUT_KEY_F6:
    drawPrimP = drawTeapot;
    break;
  case GLUT_KEY_F7:
    drawPrimP = drawCone;
    break;
  case GLUT_KEY_F8:
    drawPrimP = drawCone;
    break;
  case GLUT_KEY_F9:
    drawPrimP = drawCone;
    break;
  case GLUT_KEY_F10:
    drawPrimP = drawCone;
    break;
  case GLUT_KEY_F11:
    drawPrimP = drawCone;
    break;
  case GLUT_KEY_LEFT:
    glClearColor(1.0, 1.0, 1.0, 1.0);
		 glColor3f(0.0, 0.0, 0.0);
    break;
  case GLUT_KEY_UP:
    g_rotInc += ROT_INC;
    break;
  case GLUT_KEY_RIGHT:
    	glClearColor(0.0, 0.0, 0.0, 0.0);
		 glColor3f(1.0, 1.0, 1.0);
    break;
  case GLUT_KEY_DOWN:
    g_rotInc -= ROT_INC;
    break;
  case GLUT_KEY_PAGE_UP:
    
    break;
  case GLUT_KEY_PAGE_DOWN:
    
    break;
  case GLUT_KEY_HOME:
    
    break;
  case GLUT_KEY_END:
    
    break;
  case GLUT_KEY_INSERT:
    
    break;
  default:
    break;
  }
//  printf("special: %s %d,%d\n", name, x, y);
}

void blank()
{
}

/*
 * main
 *
 * Initialization and sets graphics callbacks
 *
 */
int main(int argc, char **argv)
{
	int mnu1,mnu2,mnu3,mnu4,mnu5,mnu6,mnu7,mnu8,mnu9,mnu10;
    /* glutInit MUST be called before any other GLUT/OpenGL calls */
    glutInit(&argc, argv);

	/* set double buffering, note no z buffering */
    glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE);
    glutInitWindowSize(600, 600);
    glutCreateWindow("3D Shapes Analysis");

	/* set callback functions. */
    glutReshapeFunc(myReshape);
    glutDisplayFunc(display);
	glutIdleFunc(myIdleFunc);
	glutKeyboardFunc(myKey);
	glutMouseFunc(myMouse);
	 glutSpecialFunc(special);

	/* set up right menu */
	mnu1=glutCreateMenu(setPrim);
	glutAddMenuEntry("Sphere", 1);
	glutAddMenuEntry("Cube", 2);
	glutAddMenuEntry("Cone", 3);
	glutAddMenuEntry("Torus", 4);
	glutAddMenuEntry("Icosahedron", 5);
	glutAddMenuEntry("Teapot", 6);
	
    mnu2=glutCreateMenu(setPrim);
	glutAddMenuEntry("White", 7);
	glutAddMenuEntry("Black", 8);
	
	mnu3=glutCreateMenu(setPrim);
	glutAddMenuEntry("Increase Speed", 9);
	glutAddMenuEntry("Decrease Speed", 10);
    glutAddMenuEntry("Stop Rotation", 17);
    
    mnu4=glutCreateMenu(setPrim);
	glutAddMenuEntry("About X-axis", 11);
	glutAddMenuEntry("About Y-axis", 12);
    glutAddMenuEntry("About z-axis", 13);

    mnu5=glutCreateMenu(setPrim);
	glutAddMenuEntry("Red", 14);
	glutAddMenuEntry("Green", 15);
    glutAddMenuEntry("Blue", 16);

    glutCreateMenu(setPrim);
	glutAddSubMenu("Shape",mnu1);
	glutAddSubMenu("Background",mnu2);
	glutAddSubMenu("Speed Variation",mnu3);
    //glutAddSubMenu("Rotation",mnu4);
    glutAddSubMenu("Foreground Colour",mnu5);	
  
    glutAddMenuEntry("Exit",25);
    
    glutAttachMenu(GLUT_RIGHT_BUTTON);
    
    glutCreateMenu(blank);
	glutAddMenuEntry("**************Help Note*****************",0);
    glutAddMenuEntry("Func Keys F1 to F6 for Shapes",0);
    glutAddMenuEntry("Up Arrow=> Increase speed of Rotation",0);
    glutAddMenuEntry("Down Arrow=> Decrease speed of Rotation",0);
    glutAddMenuEntry("Left/Right Arrow=> Toggle the Backgroud",0);
    glutAddMenuEntry("Key S/s=> Solid Shape",0);
    glutAddMenuEntry("Key W/w=> Wired Shape",0);
    glutAddMenuEntry("Key R/r=> Red Foreground",0);
    glutAddMenuEntry("Key G/g=> Green Foreground",0);
    glutAddMenuEntry("Key B/b=> Blue Foreground",0);
    glutAddMenuEntry("Key Q/q=> Quit",0);
    glutAttachMenu(GLUT_LEFT_BUTTON);
    
 
	/* set clear colour */
	glClearColor(0.0, 0.0, 0.0, 0.0);

	/* set current colour to black */
	glColor3f(1.0, 1.0, 1.0);
	
    glutMainLoop();
	return 0;
}
